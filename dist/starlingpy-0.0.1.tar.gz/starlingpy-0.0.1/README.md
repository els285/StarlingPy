# StarlingPy
A package for financial analytics for Starling Bank account holders
